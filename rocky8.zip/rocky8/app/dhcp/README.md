# DHCP
dhcpd conf

## 1. Check
         
### 1.2 Config check

    dhcpd -t -cf /etc/dhcp/dhcpd.conf
