# Wireshark
network analyzer with GUI

## 1. Install

### 1.1 Install

    dnf install wireshark wireshark-cli

### 1.2 Check version

    tshark --version
