# Remmina
remote desktop client

## 1. Install

### 1.1 Install

    dnf install epel-release
    dnf copr enable castor/remmina
    dnf install 'remmina*'
