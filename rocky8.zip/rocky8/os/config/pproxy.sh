http_proxy=http://10.10.10.180:3128

https_proxy=$http_proxy
ftp_proxy=$ftp_proxy
no_proxy="127.0.0.1"

export http_proxy https_proxy ftp_proxy no_proxy
