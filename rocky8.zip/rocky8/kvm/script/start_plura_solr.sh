#!/usr/bin/env bash

virsh start 011020-solr-sys
virsh start 011021-solr-sys

virsh start 011022-solr-sys
virsh start 011023-solr-sys

virsh start 011024-solr-sys
virsh start 011025-solr-sys

virsh start 011026-solr-sys
virsh start 011027-solr-sys

virsh start 011028-solr-sys
virsh start 011029-solr-sys

virsh start 011030-solr-sys
virsh start 011031-solr-sys

virsh start 011032-solr-sys
virsh start 011033-solr-sys

virsh start 011034-solr-sys
virsh start 011035-solr-sys

virsh start 011036-solr-sys
virsh start 011037-solr-sys

virsh start 011038-solr-sys
virsh start 011039-solr-sys

virsh start 011040-solr
virsh start 011041-solr

virsh start 011042-solr
virsh start 011043-solr

virsh start 011044-solr
virsh start 011045-solr

virsh start 011046-solr
virsh start 011047-solr

virsh start 011048-solr
virsh start 011049-solr

virsh start 011050-solr
virsh start 011051-solr

virsh start 011052-solr
virsh start 011053-solr

virsh start 011060-solr-net
virsh start 011061-solr-net

virsh start 011062-solr-net
virsh start 011063-solr-net

virsh start 011064-solr-net
virsh start 011065-solr-net

virsh start 011066-solr-net
virsh start 011067-solr-net

virsh start 011068-solr-net
virsh start 011069-solr-net

virsh start 011070-solr
virsh start 011071-solr

virsh start 011100-solr-etc
virsh start 011101-solr-etc

virsh start 011102-solr-etc
virsh start 011103-solr-etc

virsh start 011104-solr-etc
virsh start 011105-solr-etc

virsh start 011106-solr-etc
virsh start 011107-solr-etc

virsh start 011108-solr-etc
virsh start 011109-solr-etc

virsh start 011120-solr-sysd
virsh start 011121-solr-sysd

virsh start 011122-solr-sysd
virsh start 011123-solr-sysd

virsh start 011130-solr-netd
virsh start 011131-solr-netd

virsh start 011132-solr-netd
virsh start 011133-solr-netd

virsh start 011140-solr-etcd
virsh start 011141-solr-etcd

virsh start 011142-solr-etcd
virsh start 011143-solr-etcd

virsh start 011160-solr-appd
virsh start 011161-solr-appd

virsh start 011162-solr-appd
virsh start 011163-solr-appd

virsh start 011170-solr
virsh start 011171-solr

virsh start 011172-solr
virsh start 011173-solr

virsh start 011180-solr-app
virsh start 011181-solr-app

virsh start 011182-solr-app
virsh start 011183-solr-app

virsh start 011184-solr
virsh start 011185-solr

virsh start 011190-solr
virsh start 011191-solr

virsh start 011192-solr
virsh start 011193-solr

virsh start 011194-solr
virsh start 011195-solr

virsh start 011200-solr-r
virsh start 011201-solr-r

virsh start 011202-solr-r
virsh start 011203-solr-r
